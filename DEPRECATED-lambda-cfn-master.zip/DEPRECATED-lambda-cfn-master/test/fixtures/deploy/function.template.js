var lambdaCfn = require('../../../lib/lambda-cfn.js'); 

module.exports = lambdaCfn.build({
  name: 'fakeFakeRule'
});